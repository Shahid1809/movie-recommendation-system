import pandas as pd

movies=pd.read_csv('movies.csv')
ratings=pd.read_csv('ratings.csv')

print(movies.head())
print(ratings.head())

# Merge the ratings and movie info
movie_data = pd.merge(ratings, movies, on='movieId')

# Create a user-movie matrix
user_movie_matrix = movie_data.pivot_table(index='userId', columns='title', values='rating')

# Choose a movie to get recommendations for
target_movie = user_movie_matrix['Toy Story (1995)']

# Calculate correlation with other movies
similar_movies = user_movie_matrix.corrwith(target_movie)

# Create a DataFrame for recommendations
corr_df = pd.DataFrame(similar_movies, columns=['correlation'])
corr_df.dropna(inplace=True)

# Add number of ratings to filter popular ones
rating_counts = movie_data.groupby('title')['rating'].count()
corr_df['rating_count'] = rating_counts

# Recommend only if a movie has at least 2 ratings
recommendations = corr_df[corr_df['rating_count'] > 2].sort_values('correlation', ascending=False).head(10)

# Show recommendations
print("\nRecommended movies similar to Toy Story (1995):\n")
print(recommendations)
