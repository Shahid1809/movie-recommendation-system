
# 🎬 Movie Recommendation System (Mini Project)

This is a simple content-based movie recommendation system built using Python and pandas.  
It recommends movies similar to a selected movie based on user ratings and correlation.

## 📁 Files Included

- `project.py` — Main Python script to run the recommender system
- `movies.csv` — Contains movie information (titles, genres)
- `ratings.csv` — Contains user ratings for movies
- `README.md` — This file

## ⚙️ Technologies Used

- Python 🐍
- pandas
- NumPy

## 🧠 How It Works

1. Merges `movies.csv` and `ratings.csv` using `movieId`
2. Creates a user-movie rating matrix using pivot
3. Calculates similarity using correlation
4. Recommends top movies similar to **"Toy Story (1995)"**

## 📦 How to Run

1. Place all files in the same folder
2. Run the script in IDLE or any Python IDE:

```bash
python project.py
```

3. Check the console for recommendations based on "Toy Story (1995)"

## 📌 Sample Output

```
Recommended movies similar to Toy Story (1995):

                      correlation  rating_count
Jumanji (1995)               0.87              4
Grumpier Old Men (1995)      0.82              3
...
```

## ✍️ Author

Abdul Shahid  
Aspiring Data Analyst | Python Enthusiast

## 🔗 Connect

- [LinkedIn](https://www.linkedin.com/in/abdulshahid-dataanalyst)

## 🏷️ Tags

`#Python` `#DataAnalysis` `#MiniProject` `#RecommendationSystem` `#Portfolio`
